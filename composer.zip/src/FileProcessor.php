<?php

namespace App;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use RuntimeException;

class FileProcessor
{
    private Database $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    public function processUpload(array $file): string
    {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new RuntimeException("Upload failed with error code: " . $file['error']);
        }

        $originalName = $file['name'];
        $tmpPath = $file['tmp_name'];

        // 1. Get definition from DB
        $definition = $this->db->getFileDefinition($originalName);

        if (!$definition) {
            throw new RuntimeException("Arquivo não reconhecido no sistema: $originalName");
        }

        $newName = $definition['translated_name'];
        $description = $definition['description'];

        // 2. Read CSV Content
        $csvData = array_map('str_getcsv', file($tmpPath));
        if (!$csvData) {
            throw new RuntimeException("Arquivo CSV vazio ou inválido.");
        }

        // 3. Create Spreadsheet
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // 4. Inject Description at Row 1
        $sheet->setCellValue('A1', $description);
        $sheet->mergeCells('A1:Z1'); // Merge first row for description visibility (arbitrary range)
        $sheet->getStyle('A1')->getFont()->setBold(true);

        // 5. Insert CSV Data starting at Row 2
        $row = 2;
        foreach ($csvData as $rowData) {
            $col = 1;
            foreach ($rowData as $cellData) {
                $sheet->setCellValueByColumnAndRow($col, $row, $cellData);
                $col++;
            }
            $row++;
        }

        // 6. Save as XLSX
        $writer = new Xlsx($spreadsheet);
        $outputDir = __DIR__ . '/../processed_files/';
        if (!is_dir($outputDir)) {
            mkdir($outputDir, 0777, true);
        }

        $outputFilename = $newName . '.xlsx';
        $outputPath = $outputDir . $outputFilename;
        $writer->save($outputPath);

        return $outputFilename;
    }
}
